"""
Scout Card Builder - Auto Processor with License Validation
Automatically creates PowerPoint presentations from Google Sheets practice data
"""

import os
import sys
import json
import csv
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
import time
from datetime import datetime
import requests

# Configuration
DOWNLOADS_FOLDER = Path.home() / "Downloads"
SCOUT_CARDS_FOLDER = None

# Get script directory for storing config files
SCRIPT_DIR = Path(__file__).parent

# Config files stored in same folder as script
CONFIG_FILE = SCRIPT_DIR / ".scout_card_config.json"
LICENSE_FILE = SCRIPT_DIR / ".scout_card_license.json"

# License validation endpoint - YOUR RENDER SERVER
LICENSE_API_URL = "https://scout-sheets-validator.onrender.com/api/validate"


def validate_license(license_key):
    """Validate license key with server"""
    try:
        response = requests.post(
            LICENSE_API_URL,
            json={'license_key': license_key},
            timeout=10
        )
        
        if response.status_code == 200:
            return True, "License valid"
        else:
            return False, "Invalid license key"
            
    except requests.RequestException:
        # Offline fallback
        parts = license_key.split('-')
        if len(parts) >= 4:
            return True, "License valid (offline mode)"
        return False, "Invalid license format"


def check_license():
    """Check if license is activated"""
    if LICENSE_FILE.exists():
        try:
            with open(LICENSE_FILE, 'r') as f:
                data = json.load(f)
                license_key = data.get('license_key')
                
                valid, message = validate_license(license_key)
                if valid:
                    print(f"✅ License validated")
                    return True
                else:
                    print(f"❌ License invalid: {message}")
                    return False
        except:
            return False
    return False


def activate_license():
    """Activate with license key"""
    print("\n" + "="*60)
    print("SCOUT CARD BUILDER - LICENSE")
    print("="*60)
    print("\nPlease enter your license key")
    print("(You should have received this in your welcome email)")
    
    license_key = input("\nLicense Key: ").strip().upper()
    
    print("\n🔐 Validating license...")
    valid, message = validate_license(license_key)
    
    if valid:
        with open(LICENSE_FILE, 'w') as f:
            json.dump({
                'license_key': license_key,
                'activated_at': datetime.now().isoformat()
            }, f)
        
        print(f"✅ {message}")
        print("License activated successfully!")
        return True
    else:
        print(f"❌ {message}")
        print("Activation failed. Please check your license key.")
        print("Contact support@quickgamepro.com if you need help.")
        return False


def setup_config():
    """Setup scout cards folder"""
    global SCOUT_CARDS_FOLDER
    
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, 'r') as f:
            config = json.load(f)
            SCOUT_CARDS_FOLDER = Path(config.get('scout_cards_folder', ''))
    
    if not SCOUT_CARDS_FOLDER or not SCOUT_CARDS_FOLDER.exists():
        print("\n" + "="*60)
        print("SCOUT CARD BUILDER - FOLDER SETUP")
        print("="*60)
        print("\nEnter the path to your Scout Cards folder:")
        print("Example: C:\\Users\\YourName\\Documents\\Scout Cards")
        folder_path = input("\nScout Cards Folder: ").strip().strip('"')
        
        SCOUT_CARDS_FOLDER = Path(folder_path)
        
        if not SCOUT_CARDS_FOLDER.exists():
            print(f"\n❌ ERROR: Folder does not exist: {SCOUT_CARDS_FOLDER}")
            sys.exit(1)
        
        with open(CONFIG_FILE, 'w') as f:
            json.dump({'scout_cards_folder': str(SCOUT_CARDS_FOLDER)}, f)
        
        print(f"\n✅ Configuration saved!")
        print("\n" + "="*60)
        print("⚡ NEXT STEPS")
        print("="*60)
        print()
        print("1. Go to your MyQuickGamePRO folder")
        print("2. Double-click the 'scout_card_start.bat' file")
        print()
        print("="*60)
        print()
        input("Press Enter to continue THEN close this window...")


def find_best_match_file(folder_path, play_string):
    """Find best matching scout card file"""
    play_words = [w.lower().strip() for w in play_string.split() if w.strip()]
    
    best_score = 0
    best_match = None
    
    for pptx_file in folder_path.rglob("*.pptx"):
        if pptx_file.name.startswith('~'):
            continue
        
        filename = pptx_file.stem.replace('_', ' ')
        file_words = [w.lower().strip() for w in filename.split() if w.strip()]
        
        valid = True
        for fw in file_words:
            if fw not in play_words:
                valid = False
                break
        
        if valid:
            score = sum(1 for word in play_words if word in file_words)
            if score > best_score:
                best_score = score
                best_match = pptx_file
    
    return best_match


def copy_slides_from_presentation(source_pptx_path, target_prs):
    """Copy slides from source to target presentation"""
    import copy
    
    source_prs = Presentation(str(source_pptx_path))
    added_slides = []
    
    for source_slide in source_prs.slides:
        blank_layout_idx = 6 if len(target_prs.slide_layouts) > 6 else 0
        slide_layout = target_prs.slide_layouts[blank_layout_idx]
        target_slide = target_prs.slides.add_slide(slide_layout)
        
        try:
            target_slide.background.fill.solid()
            target_slide.background.fill.fore_color.rgb = RGBColor(255, 255, 255)
        except:
            pass
        
        for shape in source_slide.shapes:
            try:
                el = shape.element
                el_copy = copy.deepcopy(el)
                target_slide.shapes._spTree.append(el_copy)
            except:
                continue
        
        added_slides.append(target_slide)
    
    return added_slides


def _add_textbox(slide, text, left, top, width, height,
                 font_name, font_size, font_color,
                 bold=False, align=PP_ALIGN.CENTER,
                 border=False, border_color=RGBColor(0, 0, 0), border_pt=0.5,
                 word_wrap=False):
    """
    Internal helper: add a single formatted textbox to a slide.
    """
    tb = slide.shapes.add_textbox(left, top, width, height)

    # Border
    if border:
        tb.line.fill.solid()
        tb.line.color.rgb = border_color
        tb.line.width = Pt(border_pt)
    else:
        tb.line.fill.background()

    tf = tb.text_frame
    tf.word_wrap = word_wrap
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE

    p = tf.paragraphs[0]
    p.alignment = align

    run = p.add_run()
    run.text = text
    run.font.name = font_name
    run.font.size = Pt(font_size)
    run.font.bold = bold
    run.font.color.rgb = font_color

    return tb


def add_scout_card_textboxes(slide, play_num, dn_dist, hash_val,
                              front, blitz, coverage, play_call):
    """
    Add all overlay textboxes to a scout card slide.

    Layout (11" x 8.5" landscape):

    TOP-LEFT  — Play Number
      Bordered value box : left=0.25"  top=0.25"  w=0.75"  h=0.50"
      "PLAY #" label     : left=0.151" top=0.75"  w=1.00"  h=0.35"

    TOP-RIGHT — Down & Distance / Hash
      "DN & DIST" label  : left=8.05"  top=0.25"  w=1.75"  h=0.35"  red
      DN & DIST value    : left=8.05"  top=0.50"  w=1.75"  h=0.35"  black 14pt
      "HASH" label       : left=9.75"  top=0.25"  w=1.25"  h=0.35"  red
      HASH value         : left=9.75"  top=0.50"  w=1.25"  h=0.35"  black 14pt

    BOTTOM — Three-column (label row then value row)
      "FRONT"      label : left=0.00"  top=7.75"  w=3.50"  h=0.35"  blue
      front value        : left=0.00"  top=8.00"  w=3.50"  h=0.35"  black 14pt
      "BLITZ/STUNT"label : left=3.75"  top=7.75"  w=3.50"  h=0.35"  blue
      blitz value        : left=3.75"  top=8.00"  w=3.50"  h=0.35"  black 14pt
      "COVERAGE"   label : left=7.50"  top=7.75"  w=3.50"  h=0.35"  blue
      coverage value     : left=7.50"  top=8.00"  w=3.50"  h=0.35"  black 14pt

    All fonts: Arial Black.  Label size: 18pt.  Value size: 14pt.
    Play # value box has thin black border (0.5pt); all others no border.
    Play call is stored in slide notes.
    """

    BLACK = RGBColor(0,   0,   0)
    RED   = RGBColor(0xFF, 0x00, 0x00)
    BLUE  = RGBColor(0x00, 0x70, 0xC0)

    # ── PLAY # ───────────────────────────────────────────────────────────────

    # Value box — thin black border
    _add_textbox(
        slide,
        text      = play_num if play_num else "",
        left      = Inches(0.25), top    = Inches(0.25),
        width     = Inches(0.75), height = Inches(0.50),
        font_name = "Arial Black", font_size = 18, font_color = BLACK,
        border=True, border_color=BLACK, border_pt=0.5,
    )

    # "PLAY #" label — no border, 12pt bold
    _add_textbox(
        slide,
        text      = "PLAY #",
        left      = Inches(0.151), top    = Inches(0.75),
        width     = Inches(1.00),  height = Inches(0.35),
        font_name = "Arial Black", font_size = 12, font_color = BLACK,
        bold=True,
    )

    # ── DN & DIST ─────────────────────────────────────────────────────────────

    _add_textbox(
        slide,
        text      = "DN & DIST",
        left      = Inches(8.05), top    = Inches(0.25),
        width     = Inches(1.75), height = Inches(0.35),
        font_name = "Arial Black", font_size = 18, font_color = RED,
    )
    _add_textbox(
        slide,
        text      = dn_dist if dn_dist else "",
        left      = Inches(8.05), top    = Inches(0.50),
        width     = Inches(1.75), height = Inches(0.35),
        font_name = "Arial Black", font_size = 14, font_color = BLACK,
    )

    # ── HASH ──────────────────────────────────────────────────────────────────

    _add_textbox(
        slide,
        text      = "HASH",
        left      = Inches(9.75), top    = Inches(0.25),
        width     = Inches(1.25), height = Inches(0.35),
        font_name = "Arial Black", font_size = 18, font_color = RED,
    )
    _add_textbox(
        slide,
        text      = hash_val if hash_val else "",
        left      = Inches(9.75), top    = Inches(0.50),
        width     = Inches(1.25), height = Inches(0.35),
        font_name = "Arial Black", font_size = 14, font_color = BLACK,
    )

    # ── FRONT ─────────────────────────────────────────────────────────────────

    _add_textbox(
        slide,
        text      = "FRONT",
        left      = Inches(0.00), top    = Inches(7.75),
        width     = Inches(3.50), height = Inches(0.35),
        font_name = "Arial Black", font_size = 18, font_color = BLUE,
    )
    _add_textbox(
        slide,
        text      = front if front else "",
        left      = Inches(0.00), top    = Inches(8.00),
        width     = Inches(3.50), height = Inches(0.35),
        font_name = "Arial Black", font_size = 14, font_color = BLACK,
    )

    # ── BLITZ / STUNT ─────────────────────────────────────────────────────────

    _add_textbox(
        slide,
        text      = "BLITZ / STUNT",
        left      = Inches(3.75), top    = Inches(7.75),
        width     = Inches(3.50), height = Inches(0.35),
        font_name = "Arial Black", font_size = 18, font_color = BLUE,
    )
    _add_textbox(
        slide,
        text      = blitz if blitz else "",
        left      = Inches(3.75), top    = Inches(8.00),
        width     = Inches(3.50), height = Inches(0.35),
        font_name = "Arial Black", font_size = 14, font_color = BLACK,
    )

    # ── COVERAGE ──────────────────────────────────────────────────────────────

    _add_textbox(
        slide,
        text      = "COVERAGE",
        left      = Inches(7.50), top    = Inches(7.75),
        width     = Inches(3.50), height = Inches(0.35),
        font_name = "Arial Black", font_size = 18, font_color = BLUE,
    )
    _add_textbox(
        slide,
        text      = coverage if coverage else "",
        left      = Inches(7.50), top    = Inches(8.00),
        width     = Inches(3.50), height = Inches(0.35),
        font_name = "Arial Black", font_size = 14, font_color = BLACK,
    )

    # ── SLIDE NOTES ───────────────────────────────────────────────────────────

    if play_call:
        notes_slide = slide.notes_slide
        notes_slide.notes_text_frame.text = play_call


def add_title_slide(prs, play_call, practice_info):
    """Add a title slide for a play call"""
    blank_layout = prs.slide_layouts[6]
    slide = prs.slides.add_slide(blank_layout)
    
    try:
        slide.background.fill.solid()
        slide.background.fill.fore_color.rgb = RGBColor(255, 255, 255)
    except:
        pass
    
    title_box = slide.shapes.add_textbox(
        Inches(0.25), Inches(3.0), Inches(10.5), Inches(1.5)
    )
    title_frame = title_box.text_frame
    title_frame.text = play_call
    title_para = title_frame.paragraphs[0]
    title_para.font.name = "Arial Black"
    title_para.font.size = Pt(72)
    title_para.font.bold = True
    title_para.alignment = PP_ALIGN.CENTER
    title_frame.vertical_anchor = MSO_ANCHOR.MIDDLE
    
    subtitle_box = slide.shapes.add_textbox(
        Inches(0.25), Inches(4.25), Inches(10.5), Inches(0.75)
    )
    subtitle_frame = subtitle_box.text_frame
    subtitle_frame.text = practice_info
    subtitle_para = subtitle_frame.paragraphs[0]
    subtitle_para.font.name = "Arial"
    subtitle_para.font.size = Pt(28)
    subtitle_para.font.bold = False
    subtitle_para.font.color.rgb = RGBColor(89, 89, 89)
    subtitle_para.alignment = PP_ALIGN.CENTER
    subtitle_frame.vertical_anchor = MSO_ANCHOR.MIDDLE


def add_no_match_slide(prs, play_call, play_num, front):
    """Add a no-match slide when no scout card file is found.
    Slide is landscape: 11" wide x 8.5" tall.
    Textbox: 8" wide x 2" tall, centered on slide.
    """
    blank_layout = prs.slide_layouts[6] if len(prs.slide_layouts) > 6 else prs.slide_layouts[0]
    slide = prs.slides.add_slide(blank_layout)

    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = RGBColor(255, 255, 255)

    textbox = slide.shapes.add_textbox(
        Inches(1.5), Inches(3.25), Inches(8.0), Inches(2.0)
    )
    tf = textbox.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    tf.text = f"NO MATCH FOUND\n\n{play_call}\n{front}"

    for paragraph in tf.paragraphs:
        paragraph.font.name = "Arial"
        paragraph.font.size = Pt(24)
        paragraph.font.bold = True
        paragraph.font.color.rgb = RGBColor(255, 0, 0)
        paragraph.alignment = PP_ALIGN.CENTER


def is_play_call_in_setup(play_call, setup_list):
    """Check if play call triggers a title slide"""
    play_call_lower = play_call.lower().strip()
    for setup_item in setup_list:
        if setup_item.lower().strip() == play_call_lower:
            return True
    return False


def process_practice_data(csv_file_path):
    """Process CSV and create PowerPoint"""
    print(f"\n{'='*60}")
    print(f"📋 Processing: {csv_file_path.name}")
    print(f"{'='*60}\n")
    
    with open(csv_file_path, 'r', encoding='utf-8-sig') as f:
        all_lines = f.readlines()
    
    day_of_week      = ""
    practice_info_str = ""
    title_triggers   = []
    demo_flag        = ""
    data_start       = 0
    
    if all_lines and all_lines[0].startswith('METADATA'):
        metadata_parts = all_lines[0].strip().split(',')
        if len(metadata_parts) >= 2:
            day_of_week = metadata_parts[1].strip('"')
        if len(metadata_parts) >= 3:
            practice_info_str = metadata_parts[2].strip('"')
        if len(metadata_parts) >= 4:
            setup_plays_str = metadata_parts[3].strip('"')
            title_triggers = [t.strip() for t in setup_plays_str.split('|') if t.strip()]
        if len(metadata_parts) >= 5:
            demo_flag = metadata_parts[4].strip('"')
        data_start = 1
    
    import io
    csv_data = ''.join(all_lines[data_start:])
    reader   = csv.DictReader(io.StringIO(csv_data))
    rows     = list(reader)
    
    if not rows:
        print("❌ No data in CSV")
        return None
    
    practice_info = {
        'name': practice_info_str or 'Practice',
        'date': '',
        'team': '',
        'demo': demo_flag,
        'day':  day_of_week or 'MONDAY'
    }
    
    import re
    practice_num_match = re.search(r'Practice[_\s](\d+)', csv_file_path.name, re.IGNORECASE)
    practice_number    = practice_num_match.group(1) if practice_num_match else "1"
    
    opponent     = practice_info_str.split(' - ')[-1].strip() if ' - ' in practice_info_str else practice_info_str
    week_opponent = practice_info_str.replace(' - ', ' ') if practice_info_str else 'WEEK #1 OPPONENT'
    
    practice_info['practice_number'] = practice_number
    practice_info['opponent']        = opponent
    practice_info['week_opponent']   = week_opponent
    
    print(f"🏈 Practice: {practice_info['name']}")
    print(f"📅 Date: {practice_info['date']}")
    print(f"🏫 Team: {practice_info['team']}")

    prs = Presentation()
    prs.slide_width  = Inches(11)
    prs.slide_height = Inches(8.5)
    
    slides_added  = 0
    matches_found = 0
    no_matches    = 0
    current_session = ""
    
    # ── SET 1 ────────────────────────────────────────────────────────────────
    print("\n🔍 Processing Set 1...")
    for row in rows:
        play_call = row.get('PlayCall_Set1', '').strip()
        front     = row.get('Defense_Set1',  '').strip()   # maps to FRONT label
        play_num  = row.get('PlayNum_Set1',  '').strip()
        dn_dist   = row.get('DnDist_Set1',   '').strip()
        hash_val  = row.get('Hash_Set1',     '').strip()
        blitz     = row.get('Blitz_Set1',    '').strip()
        coverage  = row.get('Coverage_Set1', '').strip()
        
        if not play_call:
            continue
        
        if is_play_call_in_setup(play_call, title_triggers):
            add_title_slide(prs, play_call, practice_info['name'])
            current_session = play_call
            slides_added += 1
            print(f"  📄 Title slide: {play_call}")
        
        search_string = f"{play_call} {front}".strip()
        best_match    = find_best_match_file(SCOUT_CARDS_FOLDER, search_string)
        
        if best_match:
            new_slides = copy_slides_from_presentation(best_match, prs)
            if new_slides:
                last_slide = new_slides[-1]
                add_scout_card_textboxes(
                    last_slide, play_num, dn_dist, hash_val,
                    front, blitz, coverage, play_call
                )
                slides_added  += len(new_slides)
                matches_found += 1
                print(f"  ✅ {play_call} {front} → {best_match.name}")
        else:
            if play_num and play_call and front:
                add_no_match_slide(prs, play_call, play_num, front)
                slides_added += 1
                no_matches   += 1
                print(f"  ❌ No match: {play_call} {front}")
    
    # ── SET 2 ────────────────────────────────────────────────────────────────
    print("\n🔍 Processing Set 2...")
    for row in rows:
        play_call = row.get('PlayCall_Set2', '').strip()
        front     = row.get('Defense_Set2',  '').strip()   # maps to FRONT label
        play_num  = row.get('PlayNum_Set2',  '').strip()
        dn_dist   = row.get('DnDist_Set2',   '').strip()
        hash_val  = row.get('Hash_Set2',     '').strip()
        blitz     = row.get('Blitz_Set2',    '').strip()
        coverage  = row.get('Coverage_Set2', '').strip()
        
        if not play_call:
            continue
        
        if is_play_call_in_setup(play_call, title_triggers):
            add_title_slide(prs, play_call, practice_info['name'])
            current_session = play_call
            slides_added += 1
            print(f"  📄 Title slide: {play_call}")
        
        search_string = f"{play_call} {front}".strip()
        best_match    = find_best_match_file(SCOUT_CARDS_FOLDER, search_string)
        
        if best_match:
            new_slides = copy_slides_from_presentation(best_match, prs)
            if new_slides:
                last_slide = new_slides[-1]
                add_scout_card_textboxes(
                    last_slide, play_num, dn_dist, hash_val,
                    front, blitz, coverage, play_call
                )
                slides_added  += len(new_slides)
                matches_found += 1
                print(f"  ✅ {play_call} {front} → {best_match.name}")
        else:
            if play_num and play_call and front:
                add_no_match_slide(prs, play_call, play_num, front)
                slides_added += 1
                no_matches   += 1
                print(f"  ❌ No match: {play_call} {front}")
    
    # ── SAVE ─────────────────────────────────────────────────────────────────
    day_title           = practice_info['day'].title()
    week_opponent_title = practice_info['week_opponent'].title()
    output_filename     = f"{day_title} - {week_opponent_title}.pptx"
    output_path         = DOWNLOADS_FOLDER / output_filename
    
    print(f"\n💾 Saving...")
    prs.save(str(output_path))
    
    print(f"\n{'='*60}")
    print(f"✅ SUCCESS!")
    print(f"{'='*60}")
    print(f"📊 Slides: {slides_added} | Matched: {matches_found} | No match: {no_matches}")
    print(f"📁 Saved: {output_path}")
    print(f"{'='*60}\n")
    
    return output_path


def watch_folder():
    """Watch Downloads folder for CSV files"""
    print("\n" + "="*60)
    print("SCOUT CARD BUILDER - INFORMATION")
    print("="*60)
    print(f"\n👀 Watching: {DOWNLOADS_FOLDER}")
    print(f"📂 Scout cards: {SCOUT_CARDS_FOLDER}")
    print("\n✨ Export from Google Sheets and your presentation")
    print("   will be created automatically!")
    print("\n(Press Ctrl+C to stop)\n")
    
    processed_files = set()
    
    try:
        while True:
            for csv_file in DOWNLOADS_FOLDER.glob("*.csv"):
                if not csv_file.name.lower().endswith("scout_data.csv"):
                    continue
                try:
                    mod_time       = csv_file.stat().st_mtime
                    file_signature = (csv_file, mod_time)
                except:
                    continue
                
                if file_signature in processed_files:
                    continue
                
                try:
                    size1 = csv_file.stat().st_size
                    time.sleep(1)
                    size2 = csv_file.stat().st_size
                    if size1 != size2:
                        continue
                    print(f"\n🆕 New file: {csv_file.name}")
                    process_practice_data(csv_file)
                    processed_files.add(file_signature)
                except Exception as e:
                    print(f"❌ Error: {e}")
            
            time.sleep(2)
            
    except KeyboardInterrupt:
        print("\n\n👋 Stopped. Goodbye!")


def main():
    """Main entry point"""
    import sys
    
    if len(sys.argv) > 1:
        arg = sys.argv[1].lower()
        
        if arg == '--change-folder' or arg == '--folder':
            print("\n" + "="*60)
            print("🏈 SCOUT CARD BUILDER - CHANGE FOLDER")
            print("="*60)
            print("\nCurrent folder:")
            if CONFIG_FILE.exists():
                with open(CONFIG_FILE, 'r') as f:
                    config = json.load(f)
                    print(f"  {config.get('scout_cards_folder', 'Not set')}")
            else:
                print("  Not configured yet")
            print("\nEnter NEW scout cards folder path:")
            print("Example: C:\\Users\\YourName\\Documents\\Scout Cards")
            folder_path = input("\nNew Folder: ").strip().strip('"')
            if folder_path:
                new_folder = Path(folder_path)
                if new_folder.exists():
                    with open(CONFIG_FILE, 'w') as f:
                        json.dump({'scout_cards_folder': str(new_folder)}, f)
                    print(f"\n✅ Folder updated!")
                    print(f"New folder: {new_folder}")
                else:
                    print(f"\n❌ ERROR: Folder does not exist: {new_folder}")
            else:
                print("\n❌ No folder entered. Cancelled.")
            input("\nPress Enter to exit...")
            return
        
        elif arg == '--change-license' or arg == '--license':
            print("\n" + "="*60)
            print("🏈 SCOUT CARD BUILDER - CHANGE LICENSE")
            print("="*60)
            if LICENSE_FILE.exists():
                LICENSE_FILE.unlink()
                print("\n✅ Previous license removed")
            if activate_license():
                print("\n✅ New license activated successfully!")
            else:
                print("\n❌ License activation failed")
            input("\nPress Enter to exit...")
            return
        
        elif arg == '--help' or arg == '-h':
            print("\n" + "="*60)
            print("🏈 SCOUT CARD BUILDER - HELP")
            print("="*60)
            print("\nUsage:")
            print("  scout_card_auto.py              Normal run (auto-detection)")
            print("  scout_card_auto.py --folder     Change scout cards folder")
            print("  scout_card_auto.py --license    Change license key")
            print("  scout_card_auto.py --help       Show this help")
            print("\nOr just double-click the BAT files:")
            print("  scout_card_start.bat            Start normally")
            print("  change_folder.bat               Change folder")
            print("  change_license.bat              Change license")
            input("\nPress Enter to exit...")
            return
    
    print("\n" + "="*60)
    print("🏈 SCOUT CARD BUILDER")
    print("="*60)
    
    if not check_license():
        print("\n⚠️ No valid license found.")
        if not activate_license():
            print("\n❌ Cannot run without valid license.")
            input("\nPress Enter to exit...")
            sys.exit(1)
    
    setup_config()
    watch_folder()


if __name__ == "__main__":
    main()
