import os
import sys
import json
import csv
from pathlib import Path
from datetime import datetime
import time
import requests
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.dml.color import RGBColor

# Configuration
DOWNLOADS_FOLDER = Path.home() / "Downloads"
SCOUT_CARDS_FOLDER = None
SCRIPT_DIR = Path(__file__).resolve().parent
LICENSE_FILE = SCRIPT_DIR / ".scout_card_license.json"
CONFIG_FILE = SCRIPT_DIR / ".scout_card_config.json"
LICENSE_API_URL = "https://scout-sheets-validator.onrender.com/api/validate"


def validate_license(license_key):
    try:
        response = requests.post(LICENSE_API_URL, json={"license_key": license_key}, timeout=10)
        if response.status_code == 200:
            return response.json().get("valid", False)
        return False
    except:
        return False


def get_or_create_license():
    if LICENSE_FILE.exists():
        try:
            with open(LICENSE_FILE, 'r') as f:
                data = json.load(f)
                return data.get('license_key')
        except:
            pass
    
    print("\n" + "="*60)
    print("LICENSE ACTIVATION")
    print("="*60)
    print("\nPlease enter your license key:\n")
    
    license_key = input("License Key: ").strip().upper()
    
    if validate_license(license_key):
        with open(LICENSE_FILE, 'w') as f:
            json.dump({'license_key': license_key, 'activated_at': datetime.now().isoformat()}, f)
        print("\nLicense activated successfully!")
        return license_key
    else:
        print("\nInvalid license key!")
        return None


def setup_config():
    global SCOUT_CARDS_FOLDER
    
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                folder = Path(config['scout_cards_folder'])
                if folder.exists():
                    SCOUT_CARDS_FOLDER = folder
                    return
        except:
            pass
    
    print("\n" + "="*60)
    print("SCOUT CARDS FOLDER SETUP")
    print("="*60)
    print("\nWhere should scout card presentations be saved?\n")
    
    while True:
        folder_path = input("Scout Cards Folder: ").strip()
        folder = Path(folder_path)
        
        if folder.exists():
            SCOUT_CARDS_FOLDER = folder
            break
        else:
            print(f"\nFolder not found: {folder_path}\n")
    
    with open(CONFIG_FILE, 'w') as f:
        json.dump({'scout_cards_folder': str(SCOUT_CARDS_FOLDER)}, f)
    
    print(f"\nConfiguration saved!")


def create_title_slide(prs, title_text, subtitle_text):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    
    title_box = slide.shapes.add_textbox(Inches(0.25), Inches(3.0), Inches(10.5), Inches(1.5))
    title_frame = title_box.text_frame
    title_frame.word_wrap = True
    title_frame.vertical_anchor = MSO_ANCHOR.MIDDLE
    title_para = title_frame.paragraphs[0]
    title_para.text = title_text
    title_para.alignment = PP_ALIGN.CENTER
    title_para.font.name = 'Arial'
    title_para.font.size = Pt(72)
    title_para.font.bold = True
    title_para.font.color.rgb = RGBColor(0, 0, 0)
    
    subtitle_box = slide.shapes.add_textbox(Inches(0.25), Inches(4.25), Inches(10.5), Inches(0.75))
    subtitle_frame = subtitle_box.text_frame
    subtitle_frame.word_wrap = True
    subtitle_frame.vertical_anchor = MSO_ANCHOR.MIDDLE
    subtitle_para = subtitle_frame.paragraphs[0]
    subtitle_para.text = subtitle_text
    subtitle_para.alignment = PP_ALIGN.CENTER
    subtitle_para.font.name = 'Arial'
    subtitle_para.font.size = Pt(28)
    subtitle_para.font.color.rgb = RGBColor(89, 89, 89)


def add_labeled_textbox(slide, label, value, left, width):
    label_box = slide.shapes.add_textbox(left, Inches(0.65), width, Inches(0.25))
    label_frame = label_box.text_frame
    label_para = label_frame.paragraphs[0]
    label_para.text = label
    label_para.alignment = PP_ALIGN.CENTER
    label_para.font.name = 'Arial'
    label_para.font.size = Pt(10)
    label_para.font.bold = True
    
    value_box = slide.shapes.add_textbox(left, Inches(0.25), width, Inches(0.83))
    value_frame = value_box.text_frame
    value_frame.vertical_anchor = MSO_ANCHOR.MIDDLE
    value_para = value_frame.paragraphs[0]
    value_para.text = str(value)
    value_para.alignment = PP_ALIGN.CENTER
    value_para.font.name = 'Arial Black'
    value_para.font.size = Pt(20)
    value_para.font.bold = True


def create_play_slide(prs, play_data):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    
    play_num = play_data.get('Play #', '')
    dn_dist = play_data.get('DN & DIST', '')
    hash_val = play_data.get('HASH', '')
    blitz = play_data.get('BLITZ/STUNT', '')
    coverage = play_data.get('COVERAGE', '')
    session = play_data.get('Session', '')
    defense = play_data.get('Defense', '')
    
    add_labeled_textbox(slide, "PLAY #", play_num, Inches(0.25), Inches(0.75))
    add_labeled_textbox(slide, "DN & DIST", dn_dist, Inches(1.189), Inches(1.25))
    add_labeled_textbox(slide, "HASH", hash_val, Inches(2.617), Inches(0.75))
    add_labeled_textbox(slide, "BLITZ/STUNT", blitz, Inches(3.556), Inches(3.5))
    add_labeled_textbox(slide, "COVERAGE", coverage, Inches(7.252), Inches(3.5))
    
    session_box = slide.shapes.add_textbox(Inches(0.25), Inches(8.0), Inches(5.25), Inches(0.35))
    session_para = session_box.text_frame.paragraphs[0]
    session_para.text = f"Session: {session}"
    session_para.font.name = 'Arial'
    session_para.font.size = Pt(12)
    session_para.font.color.rgb = RGBColor(89, 89, 89)
    
    defense_box = slide.shapes.add_textbox(Inches(5.5), Inches(8.0), Inches(5.25), Inches(0.35))
    defense_para = defense_box.text_frame.paragraphs[0]
    defense_para.text = f"Defense: {defense}"
    defense_para.alignment = PP_ALIGN.RIGHT
    defense_para.font.name = 'Arial'
    defense_para.font.size = Pt(12)
    defense_para.font.color.rgb = RGBColor(89, 89, 89)


def process_practice_data(csv_file):
    try:
        with open(csv_file, 'r', encoding='utf-8-sig') as f:
            reader = csv.reader(f)
            rows = list(reader)
        
        if len(rows) < 2:
            print("CSV file is empty")
            return
        
        metadata_row = rows[0]
        if len(metadata_row) < 5:
            print("Invalid metadata")
            return
        
        day_of_week = metadata_row[1].strip()
        practice_info = metadata_row[2].strip()
        
        if '-' in practice_info:
            parts = practice_info.split('-', 1)
            week = parts[0].strip()
            opponent = parts[1].strip() if len(parts) > 1 else ''
        else:
            week = practice_info
            opponent = ''
        
        day = day_of_week.title()
        week_opponent = f"{week} {opponent}".strip().title()
        filename = f"{day} - {week_opponent}.pptx"
        output_path = SCOUT_CARDS_FOLDER / filename
        
        header_row = rows[1]
        headers = [h.strip() for h in header_row]
        
        prs = Presentation()
        prs.slide_width = Inches(11)
        prs.slide_height = Inches(8.5)
        
        current_section = None
        
        for row in rows[2:]:
            if not row or not any(row):
                continue
            
            if row[0] and not any(row[1:]):
                current_section = row[0].strip()
                create_title_slide(prs, practice_info.upper(), current_section)
                continue
            
            play_data = {}
            for i, header in enumerate(headers):
                if i < len(row):
                    play_data[header] = row[i].strip()
            
            if current_section:
                play_data['Session'] = current_section
            
            create_play_slide(prs, play_data)
        
        prs.save(str(output_path))
        print(f"\nCreated: {filename}")
        
    except Exception as e:
        print(f"\nError: {e}")


def watch_folder():
    print("\n" + "="*60)
    print("SCOUT CARD BUILDER - AUTO PROCESSOR")
    print("="*60)
    print(f"\nWatching: {DOWNLOADS_FOLDER}")
    print(f"Scout cards: {SCOUT_CARDS_FOLDER}")
    print("\nExport from Google Sheets and your presentation")
    print("will be created automatically!\n")
    
    processed_files = set()
    
    try:
        while True:
            for csv_file in DOWNLOADS_FOLDER.glob("*.csv"):
                if not csv_file.name.lower().endswith("scout_data.csv"):
                    continue
                
                if csv_file in processed_files:
                    continue
                
                try:
                    size1 = csv_file.stat().st_size
                    time.sleep(1)
                    size2 = csv_file.stat().st_size
                    
                    if size1 != size2:
                        continue
                    
                    print(f"\nNew file: {csv_file.name}")
                    process_practice_data(csv_file)
                    processed_files.add(csv_file)
                    
                except Exception as e:
                    print(f"Error: {e}")
            
            time.sleep(2)
            
    except KeyboardInterrupt:
        print("\n\nStopped. Goodbye!")


def main():
    print("\n" + "="*60)
    print("SCOUT CARD BUILDER")
    print("="*60)
    
    if len(sys.argv) > 1:
        arg = sys.argv[1]
        
        if arg == '--change-folder':
            global SCOUT_CARDS_FOLDER
            SCOUT_CARDS_FOLDER = None
            if CONFIG_FILE.exists():
                CONFIG_FILE.unlink()
            setup_config()
            return
    
    license_key = get_or_create_license()
    if not license_key:
        print("\nCannot run without valid license.")
        input("\nPress Enter to exit...")
        sys.exit(1)
    
    print("\nLicense validated")
    setup_config()
    watch_folder()


if __name__ == "__main__":
    main()
