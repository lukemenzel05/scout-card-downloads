@echo off

echo ============================================
echo Scout Card Builder - Installer
echo ============================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed!
    echo.
    pause
    exit /b 1
)

echo [1/2] Installing dependencies...
python -m pip install python-pptx lxml requests --quiet

echo [2/2] Creating launcher...
echo @echo off > "%~dp0scout_card_start.bat"
echo start /MIN python "%%~dp0scout_card_auto.py" >> "%~dp0scout_card_start.bat"

echo.
echo ============================================
echo Installation Complete!
echo ============================================
echo.
echo NEXT: Double-click scout_card_auto.py
echo.
pause
