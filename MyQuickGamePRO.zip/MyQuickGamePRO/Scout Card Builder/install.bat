@echo off

echo ============================================
echo Scout Card Builder - Installer
echo ============================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed!
    echo.
    echo Please install Python 3.9 or higher from:
    echo https://www.python.org/ftp/python/3.13.1/python-3.13.1-amd64.exe
    echo.
    echo Make sure to check "Add Python to PATH" during installation!
    echo.
    pause
    exit /b 1
)

echo [1/3] Installing dependencies...
python -m pip install python-pptx lxml requests --break-system-packages >nul 2>&1
if errorlevel 1 (
    python -m pip install python-pptx lxml requests
)

echo [2/3] Creating helper scripts...

REM Create VBScript launcher for invisible execution
echo Set WshShell = CreateObject("WScript.Shell") > "%~dp0scout_card_start.vbs"
echo Set fso = CreateObject("Scripting.FileSystemObject") >> "%~dp0scout_card_start.vbs"
echo scriptDir = fso.GetParentFolderName(WScript.ScriptFullName) >> "%~dp0scout_card_start.vbs"
echo Set objExec = WshShell.Exec("python -c ""import sys; print(sys.executable)""") >> "%~dp0scout_card_start.vbs"
echo pythonPath = objExec.StdOut.ReadLine() >> "%~dp0scout_card_start.vbs"
echo scriptPath = scriptDir ^& "\scout_card_auto.py" >> "%~dp0scout_card_start.vbs"
echo WshShell.Run """"  ^& pythonPath ^& """ """ ^& scriptPath ^& """", 0, False >> "%~dp0scout_card_start.vbs"
echo WScript.Quit >> "%~dp0scout_card_start.vbs"

REM Create batch file to launch the VBScript
echo @echo off > "%~dp0scout_card_start.bat"
echo wscript.exe "%~dp0scout_card_start.vbs" >> "%~dp0scout_card_start.bat"

REM Create change_folder.bat (uses python directly since it needs to show output)
echo @echo off > "%~dp0change_folder.bat"
echo python "%~dp0scout_card_auto.py" --change-folder >> "%~dp0change_folder.bat"
pause

echo [3/3] Setting up auto-start...
set SCRIPT_DIR=%~dp0
set STARTUP_FOLDER=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup
set SHORTCUT_PATH=%STARTUP_FOLDER%\Scout Card Builder.lnk

REM Create shortcut in Startup folder using PowerShell
powershell -Command "$WS = New-Object -ComObject WScript.Shell; $SC = $WS.CreateShortcut('%SHORTCUT_PATH%'); $SC.TargetPath = '%SCRIPT_DIR%scout_card_start.bat'; $SC.WorkingDirectory = '%SCRIPT_DIR%'; $SC.WindowStyle = 7; $SC.Save()" >nul 2>&1

echo.
echo ============================================
echo Installation Complete!
echo ============================================
echo.
echo Scout Card Builder is now set up to:
echo  - Start automatically when you turn on your computer
echo  - Watch your Downloads folder
echo  - Create presentations when you export from Google Sheets
echo.
echo NEXT STEP:
echo -----------
echo Double-click "scout_card_auto.py" to start it now.
echo.
echo After that, it will auto-start every time you log in!
echo.
echo TO CHANGE SCOUT CARDS FOLDER:
echo  - Double-click "change_folder.bat"
echo.
echo ============================================
echo.
pause
