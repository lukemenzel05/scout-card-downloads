@echo off

echo ============================================
echo Scout Card Builder - Install
echo ============================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not installed!
    pause
    exit /b 1
)

echo Installing packages...
python -m pip install python-pptx lxml requests

echo.
echo ============================================
echo Done!
echo ============================================
echo.
echo NEXT: Double-click scout_card_auto.py
echo.
pause
