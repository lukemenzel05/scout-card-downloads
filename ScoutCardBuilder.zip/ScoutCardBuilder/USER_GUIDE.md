# Scout Card Builder - Installation Guide

## What You Need

✅ Your license key (included in welcome email)  
✅ Python 3.9 or higher installed  
✅ Scout cards folder on your computer  

---

## Installation (5 Minutes)

### Step 1: Install Python (if not installed)

1. Go to https://www.python.org/downloads/
2. Download Python 3.9 or higher
3. **IMPORTANT:** Check "Add Python to PATH" during installation
4. Complete installation

### Step 2: Install Scout Card Builder

1. Download the Scout Card Builder ZIP file
2. Extract to any folder (e.g., `C:\ScoutCardBuilder`)
3. Double-click `install.bat`
4. Wait for installation to complete (~30 seconds)

### Step 3: First-Time Setup

The script will ask you for:

1. **License Key** - Enter the key from your welcome email  
   Format: `SCOUT-XXXX-XXXX-XXXX-XXXX`

2. **Scout Cards Folder** - Enter the path to your scout card library  
   Example: `C:\Users\YourName\Documents\Scout Cards`

That's it! Installation complete! ✅

---

## How to Use

### Daily Workflow (1 Click!)

1. Fill in your practice data in Google Sheets
2. Click **"🏈 Scout Cards"** → **"Generate Scout Card Deck"**
3. Wait 5-10 seconds
4. Your PowerPoint appears in Downloads folder! 📁

**That's it!** The script watches your Downloads folder and automatically creates the presentation.

---

## What Happens Behind the Scenes

1. Google Sheets exports CSV to Downloads folder
2. Scout Card Builder (running in background) detects the CSV
3. Script matches scout cards, creates presentation
4. PowerPoint saved to Downloads folder with timestamp

---

## Auto-Start

The installer sets up Scout Card Builder to:
- ✅ Auto-start when you log in to Windows
- ✅ Run silently in the background
- ✅ Watch Downloads folder continuously

**Desktop shortcut** created for manual start/stop.

---

## Troubleshooting

### "Python not found"
- Install Python from https://www.python.org/downloads/
- Make sure "Add Python to PATH" was checked
- Restart your computer after installing

### "License key invalid"
- Check for typos (it's case-sensitive)
- Make sure you copied the entire key
- Contact support with your order number

### "Scout cards folder not found"
- Make sure the path exists
- Use full path (e.g., `C:\Users\...`)
- No quotes needed around path

### "No presentation created"
- Make sure Scout Card Builder is running (check desktop shortcut)
- CSV must be named ending with `_scout_data.csv`
- Check Downloads folder for the CSV file

### Script won't start
- Right-click desktop shortcut → "Run as administrator"
- Check if Python is in PATH: Open Command Prompt, type `python --version`

---

## Support

**Email:** support@yourcompany.com  
**Include:**
- Your license key (last 4 digits only)
- Error messages or screenshots
- Windows version

---

## Uninstall

1. Delete the Scout Card Builder folder
2. Delete desktop shortcut
3. Remove from startup: 
   - Press `Win+R`
   - Type: `shell:startup`
   - Delete `ScoutCardBuilder.vbs`

---

## FAQ

**Q: Does this work on Mac?**  
A: Currently Windows only. Mac version coming soon.

**Q: Can I use this on multiple computers?**  
A: Each license is for one computer. Contact us for multi-computer licenses.

**Q: What if I change computers?**  
A: Contact support to transfer your license.

**Q: Does it need internet?**  
A: Only for initial license activation. Offline mode available after activation.

**Q: Where are presentations saved?**  
A: Downloads folder with timestamp (e.g., `Practice_Scout_Cards_20240315_143022.pptx`)

---

## System Requirements

- **OS:** Windows 10 or 11
- **Python:** 3.9 or higher
- **Disk Space:** 50 MB
- **RAM:** 2 GB minimum
- **Internet:** Required for license activation only

---

Enjoy your automated scout card presentations! 🏈
