"""
Scout Card Builder - Auto Processor with License Validation
Automatically creates PowerPoint presentations from Google Sheets practice data
"""

import os
import sys
import json
import csv
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
import time
from datetime import datetime
import requests

# Configuration
DOWNLOADS_FOLDER = Path.home() / "Downloads"
SCOUT_CARDS_FOLDER = None
CONFIG_FILE = Path.home() / ".scout_card_config.json"
LICENSE_FILE = Path.home() / ".scout_card_license.json"

# License validation endpoint - YOUR RENDER SERVER
LICENSE_API_URL = "https://scout-sheets-validator.onrender.com/api/validate"


def validate_license(license_key):
    """Validate license key with server"""
    try:
        response = requests.post(
            LICENSE_API_URL,
            json={'license_key': license_key},
            timeout=10
        )
        
        if response.status_code == 200:
            return True, "License valid"
        else:
            return False, "Invalid license key"
            
    except requests.RequestException:
        # Offline fallback
        parts = license_key.split('-')
        if len(parts) >= 4:
            return True, "License valid (offline mode)"
        return False, "Invalid license format"


def check_license():
    """Check if license is activated"""
    if LICENSE_FILE.exists():
        try:
            with open(LICENSE_FILE, 'r') as f:
                data = json.load(f)
                license_key = data.get('license_key')
                
                valid, message = validate_license(license_key)
                if valid:
                    print(f"✅ License validated")
                    return True
                else:
                    print(f"❌ License invalid: {message}")
                    return False
        except:
            return False
    return False


def activate_license():
    """Activate with license key"""
    print("\n" + "="*60)
    print("SCOUT CARD BUILDER - LICENSE ACTIVATION")
    print("="*60)
    print("\nPlease enter your license key")
    print("(You should have received this in your welcome email)")
    
    license_key = input("\nLicense Key: ").strip().upper()
    
    print("\n🔐 Validating license...")
    valid, message = validate_license(license_key)
    
    if valid:
        with open(LICENSE_FILE, 'w') as f:
            json.dump({
                'license_key': license_key,
                'activated_at': datetime.now().isoformat()
            }, f)
        
        print(f"✅ {message}")
        print("License activated successfully!")
        return True
    else:
        print(f"❌ {message}")
        print("Activation failed. Please check your license key.")
        print("Contact support@quickgamepro.com if you need help.")
        return False


def setup_config():
    """Setup scout cards folder"""
    global SCOUT_CARDS_FOLDER
    
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, 'r') as f:
            config = json.load(f)
            SCOUT_CARDS_FOLDER = Path(config.get('scout_cards_folder', ''))
    
    if not SCOUT_CARDS_FOLDER or not SCOUT_CARDS_FOLDER.exists():
        print("\n" + "="*60)
        print("SCOUT CARDS FOLDER SETUP")
        print("="*60)
        print("\nEnter the path to your Scout Cards folder:")
        print("Example: C:\\Users\\YourName\\Documents\\Scout Cards")
        folder_path = input("\nScout Cards Folder: ").strip().strip('"')
        
        SCOUT_CARDS_FOLDER = Path(folder_path)
        
        if not SCOUT_CARDS_FOLDER.exists():
            print(f"\n❌ ERROR: Folder does not exist: {SCOUT_CARDS_FOLDER}")
            sys.exit(1)
        
        with open(CONFIG_FILE, 'w') as f:
            json.dump({'scout_cards_folder': str(SCOUT_CARDS_FOLDER)}, f)
        
        print(f"\n✅ Configuration saved!")


def find_best_match_file(folder_path, play_string):
    """Find best matching scout card file"""
    play_words = [w.lower().strip() for w in play_string.split() if w.strip()]
    
    best_score = 0
    best_match = None
    
    for pptx_file in folder_path.rglob("*.pptx"):
        if pptx_file.name.startswith('~'):
            continue
        
        filename = pptx_file.stem.replace('_', ' ')
        file_words = [w.lower().strip() for w in filename.split() if w.strip()]
        
        valid = True
        for fw in file_words:
            if fw not in play_words:
                valid = False
                break
        
        if valid:
            score = sum(1 for word in play_words if word in file_words)
            if score > best_score:
                best_score = score
                best_match = pptx_file
    
    return best_match


def copy_slides_from_presentation(source_pptx_path, target_prs):
    """Copy slides from source to target presentation"""
    import copy
    
    source_prs = Presentation(str(source_pptx_path))
    added_slides = []
    
    for source_slide in source_prs.slides:
        blank_layout_idx = 6 if len(target_prs.slide_layouts) > 6 else 0
        slide_layout = target_prs.slide_layouts[blank_layout_idx]
        target_slide = target_prs.slides.add_slide(slide_layout)
        
        try:
            target_slide.background.fill.solid()
            target_slide.background.fill.fore_color.rgb = RGBColor(255, 255, 255)
        except:
            pass
        
        for shape in source_slide.shapes:
            try:
                el = shape.element
                el_copy = copy.deepcopy(el)
                target_slide.shapes._spTree.append(el_copy)
            except:
                continue
        
        added_slides.append(target_slide)
    
    return added_slides


def add_labeled_textbox(slide, label, value, left, width):
    """Add labeled textbox to slide"""
    top_label = Inches(0.25)
    height_label = Inches(0.20)
    
    label_box = slide.shapes.add_textbox(left, top_label, width, height_label)
    label_frame = label_box.text_frame
    label_frame.text = label
    label_frame.word_wrap = False
    label_frame.vertical_anchor = MSO_ANCHOR.BOTTOM
    
    label_para = label_frame.paragraphs[0]
    label_para.font.name = "Arial"
    label_para.font.size = Pt(9)
    label_para.font.bold = True
    label_para.alignment = PP_ALIGN.CENTER
    
    top_value = Inches(0.45)
    height_value = Inches(0.35)
    
    value_box = slide.shapes.add_textbox(left, top_value, width, height_value)
    value_frame = value_box.text_frame
    value_frame.text = str(value) if value else ""
    value_frame.word_wrap = False
    value_frame.vertical_anchor = MSO_ANCHOR.TOP
    
    value_para = value_frame.paragraphs[0]
    value_para.font.name = "Arial"
    value_para.font.size = Pt(16)
    value_para.font.bold = False
    value_para.alignment = PP_ALIGN.CENTER


def add_scout_card_textboxes(slide, play_num, dn_dist, hash, blitz, coverage, session_title, defense, play_call):
    """Add textboxes to scout card slide"""
    add_labeled_textbox(slide, "PLAY #", play_num, Inches(0.25), Inches(0.75))
    add_labeled_textbox(slide, "DN & DIST", dn_dist, Inches(1.25), Inches(1.25))
    add_labeled_textbox(slide, "HASH", hash, Inches(2.80), Inches(0.75))
    add_labeled_textbox(slide, "BLITZ / STUNT", blitz, Inches(4.80), Inches(3.50))
    add_labeled_textbox(slide, "COVERAGE", coverage, Inches(9.50), Inches(3.50))
    
    if session_title:
        textbox = slide.shapes.add_textbox(Inches(0.25), Inches(6.97), Inches(7.0), Inches(0.25))
        text_frame = textbox.text_frame
        text_frame.text = session_title
        text_frame.vertical_anchor = MSO_ANCHOR.MIDDLE
        paragraph = text_frame.paragraphs[0]
        paragraph.font.name = "Arial"
        paragraph.font.size = Pt(12)
        paragraph.alignment = PP_ALIGN.LEFT
    
    if defense:
        textbox = slide.shapes.add_textbox(Inches(6.0), Inches(7.0), Inches(7.0), Inches(0.25))
        text_frame = textbox.text_frame
        text_frame.text = defense
        text_frame.vertical_anchor = MSO_ANCHOR.MIDDLE
        paragraph = text_frame.paragraphs[0]
        paragraph.font.name = "Arial"
        paragraph.font.size = Pt(12)
        paragraph.font.italic = True
        paragraph.alignment = PP_ALIGN.RIGHT
    
    if play_call:
        notes_slide = slide.notes_slide
        text_frame = notes_slide.notes_text_frame
        text_frame.text = play_call


def add_title_slide(prs, title_text, practice_info):
    """Add title slide"""
    title_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(title_layout)
    title = slide.shapes.title
    subtitle = slide.placeholders[1]
    title.text = title_text
    subtitle.text = f"{practice_info.get('team', '')} - {practice_info.get('date', '')}"


def add_no_match_slide(prs, play_call, play_num, defense):
    """Add no match slide"""
    blank_layout = prs.slide_layouts[6] if len(prs.slide_layouts) > 6 else prs.slide_layouts[0]
    slide = prs.slides.add_slide(blank_layout)
    
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = RGBColor(255, 255, 255)
    
    textbox = slide.shapes.add_textbox(Inches(2.5), Inches(3.0), Inches(8.0), Inches(1.5))
    text_frame = textbox.text_frame
    text_frame.text = f"NO MATCH FOUND\n\n{play_call}\n{defense}"
    
    for paragraph in text_frame.paragraphs:
        paragraph.font.name = "Arial"
        paragraph.font.size = Pt(24)
        paragraph.font.bold = True
        paragraph.font.color.rgb = RGBColor(255, 0, 0)
        paragraph.alignment = PP_ALIGN.CENTER


def is_play_call_in_setup(play_call, setup_list):
    """Check if play call triggers title slide"""
    play_call_lower = play_call.lower().strip()
    for setup_item in setup_list:
        if setup_item.lower().strip() == play_call_lower:
            return True
    return False


def process_practice_data(csv_file_path):
    """Process CSV and create PowerPoint"""
    print(f"\n{'='*60}")
    print(f"📋 Processing: {csv_file_path.name}")
    print(f"{'='*60}\n")
    
    with open(csv_file_path, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    
    if not rows:
        print("❌ No data in CSV")
        return None
    
    first_row = rows[0]
    practice_name = first_row.get('PracticeName', 'Practice')
    practice_date = first_row.get('PracticeDate', '')
    team_name = first_row.get('TeamName', '')
    
    practice_info = {'name': practice_name, 'date': practice_date, 'team': team_name}
    
    title_triggers_str = first_row.get('TitleTriggers', '')
    title_triggers = [t.strip() for t in title_triggers_str.split('|') if t.strip()]
    
    print(f"🏈 Practice: {practice_name}")
    print(f"📅 Date: {practice_date}")
    print(f"🏫 Team: {team_name}")
    
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    
    add_title_slide(prs, f"{practice_name} Scout Cards", practice_info)
    
    slides_added = 1
    matches_found = 0
    no_matches = 0
    current_session = ""
    
    print("\n🔍 Processing Set 1...")
    for row in rows:
        play_call = row.get('PlayCall_Set1', '').strip()
        defense = row.get('Defense_Set1', '').strip()
        play_num = row.get('PlayNum_Set1', '').strip()
        dn_dist = row.get('DnDist_Set1', '').strip()
        hash = row.get('Hash_Set1', '').strip()
        blitz = row.get('Blitz_Set1', '').strip()
        coverage = row.get('Coverage_Set1', '').strip()
        
        if not play_call:
            continue
        
        if is_play_call_in_setup(play_call, title_triggers):
            add_title_slide(prs, play_call, practice_info)
            current_session = play_call
            slides_added += 1
            print(f"  📄 Title slide: {play_call}")
        
        search_string = f"{play_call} {defense}".strip()
        best_match = find_best_match_file(SCOUT_CARDS_FOLDER, search_string)
        
        if best_match:
            new_slides = copy_slides_from_presentation(best_match, prs)
            if new_slides:
                last_slide = new_slides[-1]
                add_scout_card_textboxes(last_slide, play_num, dn_dist, hash, blitz, coverage, current_session, defense, play_call)
                slides_added += len(new_slides)
                matches_found += 1
                print(f"  ✅ {play_call} {defense} → {best_match.name}")
        else:
            if play_num and play_call and defense:
                add_no_match_slide(prs, play_call, play_num, defense)
                slides_added += 1
                no_matches += 1
                print(f"  ❌ No match: {play_call} {defense}")
    
    print("\n🔍 Processing Set 2...")
    for row in rows:
        play_call = row.get('PlayCall_Set2', '').strip()
        defense = row.get('Defense_Set2', '').strip()
        play_num = row.get('PlayNum_Set2', '').strip()
        dn_dist = row.get('DnDist_Set2', '').strip()
        hash = row.get('Hash_Set2', '').strip()
        blitz = row.get('Blitz_Set2', '').strip()
        coverage = row.get('Coverage_Set2', '').strip()
        
        if not play_call:
            continue
        
        if is_play_call_in_setup(play_call, title_triggers):
            add_title_slide(prs, play_call, practice_info)
            current_session = play_call
            slides_added += 1
            print(f"  📄 Title slide: {play_call}")
        
        search_string = f"{play_call} {defense}".strip()
        best_match = find_best_match_file(SCOUT_CARDS_FOLDER, search_string)
        
        if best_match:
            new_slides = copy_slides_from_presentation(best_match, prs)
            if new_slides:
                last_slide = new_slides[-1]
                add_scout_card_textboxes(last_slide, play_num, dn_dist, hash, blitz, coverage, current_session, defense, play_call)
                slides_added += len(new_slides)
                matches_found += 1
                print(f"  ✅ {play_call} {defense} → {best_match.name}")
        else:
            if play_num and play_call and defense:
                add_no_match_slide(prs, play_call, play_num, defense)
                slides_added += 1
                no_matches += 1
                print(f"  ❌ No match: {play_call} {defense}")
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_filename = f"{practice_name}_Scout_Cards_{timestamp}.pptx"
    output_path = DOWNLOADS_FOLDER / output_filename
    
    print(f"\n💾 Saving...")
    prs.save(str(output_path))
    
    print(f"\n{'='*60}")
    print(f"✅ SUCCESS!")
    print(f"{'='*60}")
    print(f"📊 Slides: {slides_added} | Matched: {matches_found} | No match: {no_matches}")
    print(f"📁 Saved: {output_path}")
    print(f"{'='*60}\n")
    
    return output_path


def watch_folder():
    """Watch Downloads folder for CSV files"""
    print("\n" + "="*60)
    print("SCOUT CARD BUILDER - AUTO PROCESSOR")
    print("="*60)
    print(f"\n👀 Watching: {DOWNLOADS_FOLDER}")
    print(f"📂 Scout cards: {SCOUT_CARDS_FOLDER}")
    print("\n✨ Export from Google Sheets and your presentation")
    print("   will be created automatically!")
    print("\n(Press Ctrl+C to stop)\n")
    
    processed_files = set()
    
    try:
        while True:
            for csv_file in DOWNLOADS_FOLDER.glob("*_scout_data.csv"):
                if csv_file in processed_files:
                    continue
                
                try:
                    size1 = csv_file.stat().st_size
                    time.sleep(1)
                    size2 = csv_file.stat().st_size
                    
                    if size1 != size2:
                        continue
                    
                    print(f"\n🆕 New file: {csv_file.name}")
                    process_practice_data(csv_file)
                    processed_files.add(csv_file)
                    
                except Exception as e:
                    print(f"❌ Error: {e}")
            
            time.sleep(2)
            
    except KeyboardInterrupt:
        print("\n\n👋 Stopped. Goodbye!")


def main():
    """Main entry point"""
    print("\n" + "="*60)
    print("🏈 SCOUT CARD BUILDER")
    print("="*60)
    
    if not check_license():
        print("\n⚠️ No valid license found.")
        if not activate_license():
            print("\n❌ Cannot run without valid license.")
            input("\nPress Enter to exit...")
            sys.exit(1)
    
    setup_config()
    watch_folder()


if __name__ == "__main__":
    main()
