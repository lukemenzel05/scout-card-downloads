@echo off

echo ============================================
echo Scout Card Builder - Installer
echo ============================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed!
    echo.
    echo Please install Python 3.9 or higher from:
    echo https://www.python.org/ftp/python/3.13.1/python-3.13.1-amd64.exe
    echo.
    echo Make sure to check "Add Python to PATH" during installation!
    echo.
    pause
    exit /b 1
)

echo [1/2] Installing dependencies...
python -m pip install python-pptx lxml requests --break-system-packages >nul 2>&1
if errorlevel 1 (
    python -m pip install python-pptx lxml requests
)

echo [2/2] Installation complete!
echo.
echo ============================================
echo Installation Successful!
echo ============================================
echo.
echo NEXT STEP:
echo -----------
echo In the ScoutCardBuilder folder, double-click
echo "scout_card_auto.py" to start the Scout Card Builder.
echo.
echo You will be prompted to:
echo  1. Enter your license key
echo  2. Specify your scout cards folder
echo.
echo After that, it will automatically watch your
echo Downloads folder and create presentations!
echo.
echo ============================================
echo.
pause
