@echo off
echo ============================================
echo Scout Card Builder - Installer
echo ============================================
echo.

REM Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed!
    echo.
    echo Please install Python 3.9 or higher from:
    echo https://www.python.org/downloads/
    echo.
    echo Make sure to check "Add Python to PATH" during installation!
    pause
    exit /b 1
)

echo [1/4] Installing dependencies...
pip install python-pptx lxml requests --quiet
if errorlevel 1 (
    echo ERROR: Failed to install dependencies
    pause
    exit /b 1
)

echo [2/4] Creating start script...
set SCRIPT_PATH=%~dp0scout_card_auto.py
set STARTUP_FOLDER=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup

REM Create VBS script for silent startup
echo Set WshShell = CreateObject("WScript.Shell") > "%STARTUP_FOLDER%\ScoutCardBuilder.vbs"
echo WshShell.Run "python ""%SCRIPT_PATH%""", 0, False >> "%STARTUP_FOLDER%\ScoutCardBuilder.vbs"

echo [3/4] Creating desktop shortcut...
set DESKTOP=%USERPROFILE%\Desktop
echo Set oWS = WScript.CreateObject("WScript.Shell") > CreateShortcut.vbs
echo sLinkFile = "%DESKTOP%\Scout Card Builder.lnk" >> CreateShortcut.vbs
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> CreateShortcut.vbs
echo oLink.TargetPath = "python" >> CreateShortcut.vbs
echo oLink.Arguments = """%SCRIPT_PATH%""" >> CreateShortcut.vbs
echo oLink.WorkingDirectory = "%~dp0" >> CreateShortcut.vbs
echo oLink.Description = "Scout Card Builder Auto Processor" >> CreateShortcut.vbs
echo oLink.Save >> CreateShortcut.vbs
cscript CreateShortcut.vbs >nul
del CreateShortcut.vbs

echo [4/4] Installation complete!
echo.
echo ============================================
echo Installation successful!
echo ============================================
echo.
echo The Scout Card Builder will:
echo  - Auto-start when you log in to Windows
echo  - Watch your Downloads folder
echo  - Create presentations automatically
echo.
echo Desktop shortcut created for manual start.
echo.
choice /C YN /M "Start Scout Card Builder now"
if errorlevel 2 goto end
if errorlevel 1 goto start

:start
start "" python "%SCRIPT_PATH%"
goto end

:end
echo.
echo Installation complete!
pause
