@echo off
setlocal enabledelayedexpansion

echo ============================================
echo Scout Card Builder - Installer
echo ============================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed!
    echo.
    echo Please install Python 3.9 or higher from:
    echo https://www.python.org/ftp/python/3.13.1/python-3.13.1-amd64.exe
    echo.
    echo Make sure to check "Add Python to PATH" during installation!
    echo.
    pause
    exit /b 1
)

echo [1/4] Installing dependencies...
python -m pip install python-pptx lxml requests --break-system-packages >nul 2>&1
if errorlevel 1 (
    python -m pip install python-pptx lxml requests
)

echo [2/4] Creating start script...
echo @echo off > scout_card_start.bat
echo python "%~dp0scout_card_auto.py" >> scout_card_start.bat

echo [3/4] Creating desktop shortcut...
set SCRIPT_DIR=%~dp0
set SHORTCUT_PATH=%USERPROFILE%\Desktop\Scout Card Builder.lnk
powershell -Command "$WS = New-Object -ComObject WScript.Shell; $SC = $WS.CreateShortcut('%SHORTCUT_PATH%'); $SC.TargetPath = '%SCRIPT_DIR%scout_card_start.bat'; $SC.WorkingDirectory = '%SCRIPT_DIR%'; $SC.IconLocation = 'C:\Windows\System32\imageres.dll,2'; $SC.Save()" >nul 2>&1

echo [4/4] Installation complete!
echo.
echo ============================================
echo Installation successful!
echo ============================================
echo.
echo The Scout Card Builder will now start for initial setup.
echo You will need to:
echo  1. Enter your license key
echo  2. Specify your scout cards folder location
echo.
echo After setup, the program will:
echo  - Watch your Downloads folder automatically
echo  - Create presentations when you export from Google Sheets
echo.
echo Desktop shortcut created for future use.
echo.
echo Starting Scout Card Builder...
echo ============================================
echo.

REM Launch the Scout Card Builder
python scout_card_auto.py

echo.
echo ============================================
echo Setup Complete!
echo ============================================
echo.
echo You can now:
echo  1. Use the desktop shortcut to start anytime
echo  2. Export from Google Sheets to auto-generate presentations
echo.
pause
