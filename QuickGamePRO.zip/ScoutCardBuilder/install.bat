@echo off
setlocal enabledelayedexpansion

echo ============================================
echo Scout Card Builder - Installer
echo ============================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed!
    echo.
    echo Please install Python 3.9 or higher from:
    echo https://www.python.org/ftp/python/3.13.1/python-3.13.1-amd64.exe
    echo.
    echo Make sure to check "Add Python to PATH" during installation!
    echo.
    pause
    exit /b 1
)

echo [1/4] Installing dependencies...
python -m pip install python-pptx lxml requests --break-system-packages >nul 2>&1
if errorlevel 1 (
    python -m pip install python-pptx lxml requests
)

echo [2/4] Creating start script...
REM Create a start script for future use
echo @echo off > "%~dp0scout_card_start.bat"
echo python "%~dp0scout_card_auto.py" >> "%~dp0scout_card_start.bat"

echo [3/4] Setup complete!
echo [4/4] Installation complete!
echo.
echo ============================================
echo Installation successful!
echo ============================================
echo.
echo The Scout Card Builder will now start for initial setup.
echo You will need to:
echo  1. Enter your license key
echo  2. Specify your scout cards folder location
echo.
echo After setup, the program will:
echo  - Watch your Downloads folder automatically
echo  - Create presentations when you export from Google Sheets
echo.
echo Starting Scout Card Builder...
echo ============================================
echo.

REM Launch the Scout Card Builder with full path
python "%~dp0scout_card_auto.py"

echo.
echo ============================================
echo Setup Complete!
echo ============================================
echo.
echo Scout Card Builder is now running.
echo It will watch your Downloads folder and auto-generate
echo presentations when you export from Google Sheets.
echo.
pause
